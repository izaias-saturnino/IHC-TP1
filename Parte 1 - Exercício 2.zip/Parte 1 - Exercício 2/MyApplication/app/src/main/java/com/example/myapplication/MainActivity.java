package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.io.Console;

public class MainActivity extends AppCompatActivity {

    private EditText et1;

    public void Send(View view)
    {
        Intent i = new Intent(this, Main2Activity.class);
        et1 = (EditText) findViewById(R.id.txt_number1);
        String res = et1.getText().toString();
        i.putExtra("data", res);
        //i.putExtra("data", res.getText().toString());
        try {
            startActivity(i);
        }catch (Exception e){
            Log.d("STATE", String.valueOf(e));
        }
    }
    public void sum(View view)
    {
        //
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et1 = (EditText) findViewById(R.id.txt_number1); // ID from component
        Toast.makeText(this, "Value: " + et1.getText().toString(), Toast.LENGTH_SHORT).show();
// The activity is created
    }

    @Override
    protected void onStart() {
        super.onStart();
        Toast.makeText(this, "OnStart", Toast.LENGTH_SHORT).show();
// The activity is about to become visible.
    }
    @Override
    protected void onResume() {
        super.onResume();
        Toast.makeText(this, "OnResume", Toast.LENGTH_SHORT).show();
//The activity has become visible (now it "resumes").
    }
    @Override
    protected void onPause() {
        super.onPause();
        Toast.makeText(this, "OnPause", Toast.LENGTH_SHORT).show();
// Focus on another activity (this activity is about to be "stopped").
    }
    @Override
    protected void onStop() {
        super.onStop();
        Toast.makeText(this, "OnStop", Toast.LENGTH_SHORT).show();
// The activity is no longer visible (now it is "stopped")
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Toast.makeText(this, "OnDestroy", Toast.LENGTH_SHORT).show();
// The activity is about to be destroyed.
    }
}