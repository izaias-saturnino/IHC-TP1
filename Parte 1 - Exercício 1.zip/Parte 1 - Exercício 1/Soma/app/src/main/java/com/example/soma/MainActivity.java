package com.example.soma;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void Somar(View view){
        EditText et1;
        et1 = (EditText) findViewById(R.id.v1);

        EditText et2;
        et2 = (EditText) findViewById(R.id.v2);

        String t1 = et1.getText().toString();
        String t2 = et2.getText().toString();

        String result = "Digite entradas válidas";
        try{
            result = (Double.parseDouble(t1) + Double.parseDouble(t2)) + "";
        }catch(Exception e){
            Log.d("result", result);
            Log.d("t1", t1);
            Log.d("t2", t2);
        }

        Log.d("result", result);
        Log.d("t1", t1);
        Log.d("t2", t2);

        TextView tv = findViewById(R.id.tv);
        tv.setText(result);
    }
}