package com.example.sensor;

import androidx.appcompat.app.AppCompatActivity;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements SensorEventListener {
    private SensorManager mSensorManager;
    private Sensor mAccelerometer;
    TextView coordinate1;
    TextView coordinate2;
    TextView coordinate3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        mSensorManager = (SensorManager)getSystemService(SENSOR_SERVICE);

        if(mSensorManager != null) {
            mAccelerometer = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

            if(mAccelerometer != null) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.activity_main);
            }
            else{
                Toast.makeText(this, "Accelerometer service not detected.", Toast.LENGTH_SHORT).show();
            }
        }
        else{
            Toast.makeText(this, "Sensor service not detected.", Toast.LENGTH_SHORT).show();
        }
    }
    @Override
    protected void onResume() {
        super.onResume();
        if(mAccelerometer != null) {
            mSensorManager.registerListener(this, mAccelerometer, SensorManager.SENSOR_DELAY_NORMAL);
        }
    }
    @Override
    protected void onPause() {
        super.onPause();
        if(mAccelerometer != null) {
            mSensorManager.unregisterListener(this);
        }
    }
    @Override
    public void onSensorChanged(SensorEvent event) {
        coordinate1 = (TextView) findViewById(R.id.textView);
        coordinate2 = (TextView) findViewById(R.id.textView2);
        coordinate3 = (TextView) findViewById(R.id.textView3);
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            float sensorX = event.values[0];
            float sensorY = event.values[1];
            float sensorZ = event.values[2];
            coordinate1.setText("X: " + String.valueOf(sensorX));
            coordinate2.setText("Y: " + String.valueOf(sensorY));
            coordinate3.setText("Z: " + String.valueOf(sensorZ));
        }
    }
    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy)
    {
    }
}