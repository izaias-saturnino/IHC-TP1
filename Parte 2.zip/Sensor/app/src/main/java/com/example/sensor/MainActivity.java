package com.example.sensor;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements SensorEventListener {
    private SensorManager mSensorManager;

    private Sensor light;
    private Sensor gyroscope;
    TextView lightValue;
    TextView gyroX;
    TextView gyroY;
    TextView gyroZ;
    TextView latitude;
    TextView longitude;
    Button getGPSBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        mSensorManager = (SensorManager)getSystemService(SENSOR_SERVICE);

        light = mSensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);
        gyroscope = mSensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getGPSBtn = (Button) findViewById(R.id.getGPSBtn);
        ActivityCompat.requestPermissions(MainActivity.this, new
                String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 123);
    }

    public void GPSToast(View v) {
        GPSTracker g = new GPSTracker(getApplicationContext());
        Location l = g.getLocation();
        if(l!=null)
        {
            double lat = l.getLatitude();
            double longi = l.getLongitude();
            Toast.makeText(getApplicationContext(), "LAT: "+lat + "\nLONG: " +
                    longi, Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        mSensorManager.registerListener(this, light, SensorManager.SENSOR_DELAY_NORMAL);
        mSensorManager.registerListener(this, gyroscope, SensorManager.SENSOR_DELAY_NORMAL);
    }
    @Override
    protected void onPause() {
        super.onPause();
        mSensorManager.unregisterListener(this);
    }
    @Override
    public void onSensorChanged(SensorEvent event) {
        Sensor sensor = event.sensor;

        lightValue = (TextView) findViewById(R.id.light);
        gyroX = (TextView) findViewById(R.id.gx);
        gyroY = (TextView) findViewById(R.id.gy);
        gyroZ = (TextView) findViewById(R.id.gz);

        if(sensor.getType() == Sensor.TYPE_LIGHT)
        {
            lightValue.setText("Light Intensity: " + event.values[0]);
        }
        if(sensor.getType() == Sensor.TYPE_GYROSCOPE)
        {
            gyroX.setText("X rotation: " + event.values[0]);
            gyroY.setText("Y rotation: " + event.values[1]);
            gyroZ.setText("Z rotation: " + event.values[2]);
        }
    }
    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy)
    {
    }
}